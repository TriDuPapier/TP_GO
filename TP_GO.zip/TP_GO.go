package main

import (
	"bufio"
	"flag"
	"fmt"
	"net/http"
	"os"
	"sync"
	"time"
)

var (
	dictPath  string
	target    string
	workers   int
	quietMode bool
)

func init() {
	flag.StringVar(&dictPath, "d", "", "Path to dictionary file")
	flag.StringVar(&target, "t", "", "Target to enumerate")
	flag.IntVar(&workers, "w", 1, "Number of workers to run")
	flag.BoolVar(&quietMode, "q", false, "When set to true, only show HTTP 200")
	flag.Parse()
}

func worker(urls <-chan string, wg *sync.WaitGroup) {
	defer wg.Done()
	for url := range urls {
		resp, err := http.Get(url)
		if err != nil {
			continue
		}
		resp.Body.Close()
		if quietMode {
			if resp.StatusCode == 200 {
				fmt.Println(url, resp.StatusCode)
			}
		} else {
			fmt.Println(url, resp.StatusCode)
		}
	}
}

func main() {
	if dictPath == "" || target == "" {
		fmt.Println("Usage: go run main.go -d <dictionary> -t <target> -w <workers> -q")
		os.Exit(1)
	}

	file, err := os.Open(dictPath)
	if err != nil {
		fmt.Println("Error opening dictionary file:", err)
		os.Exit(1)
	}
	defer file.Close()

	urls := make(chan string, workers)
	var wg sync.WaitGroup

	for i := 0; i < workers; i++ {
		wg.Add(1)
		go worker(urls, &wg)
	}

	fmt.Println("Starting scan...")
	start := time.Now()
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		word := scanner.Text()
		urls <- fmt.Sprintf("http://%s/%s", target, word)
	}

	close(urls)
	wg.Wait()

	fmt.Printf("Scan done in %v\n", time.Since(start))
}
